# Der perfekte Gipfel: QGIS-Arbeitsprojekt

## Start

1. Das ZIP vollständig entpacken. Projekt und Unterordner zusammenlassen.
2. `Perfekter_Gipfel.qgz` in QGIS 3.x öffnen. Alternativ liegt dieselbe Projektdefinition als `.qgs` bei.
3. Die Startansicht zeigt das lokale Gipfelpaar A und B. Alle Daten sind bereits enthalten; es ist keine Internetverbindung und kein SAGA-/GRASS-Plugin erforderlich.
4. Für die Erweiterung auf den gesamten Ausschnitt: Rechtsklick auf `dgm_10m` → **Auf Layer zoomen**. Das Raster muss dafür nicht sichtbar geschaltet werden.

Die Datenquellen sind relativ zum Projekt gespeichert. Für eigene Änderungen empfiehlt sich eine Arbeitskopie des gesamten Ordners.

## Datengrundlage

- Tiroler Alpen / Raum Stubai, Mittelpunkt ungefähr 11,378° E / 47,118° N.
- Original: `gisma/perfectPeak`, Commit `37b49f1`, `inst/data/demo.asc`.
- Quelle laut Repository: Land Tirol, aus Laserscandaten abgeleitetes DGM.
- 324 Spalten × 360 Zeilen, Zellweite 10 m; Umfang 3,24 × 3,60 km.
- Koordinatensystem laut Repository: **MGI / Austria GK West, EPSG:31254**, Einheiten Meter.
- Der ASCII-Datei fehlt eine eigene CRS-Datei. Das CRS wurde entsprechend der Repository-Dokumentation zugewiesen. Es fand keine räumliche Neuberechnung des DGM statt.
- Geotiff-Werte stimmen mit den als Float32 eingelesenen Originalwerten überein.
- Lizenz laut Repository: **CC BY 3.0 AT**. Namensnennung: **Land Tirol; bereitgestellt über perfectPeak, Chris Reudenbach**.
- Aufnahmejahr, vertikaler Höhenbezug und Höhenfehler sind in der mitgelieferten DEM-Beschreibung nicht spezifiziert. Die Rasterweite von 10 m ist keine Angabe zur Höhengenauigkeit.

Quellen, Lizenzhinweis und SHA256 des Originals stehen zusätzlich unter `quellen/`.

## Layer

| Layer | Zweck |
|---|---|
| Gipfelkandidaten A–F (DEM-Maxima) | Ausgewählte lokale Maxima des DGM, keine amtlich verifizierten Gipfelnamen und kein vollständiges Gipfelinventar; beim Öffnen ausgeblendet |
| Eigene Verbindungen und Hypothesen | Leerer Linienlayer für eingezeichnete Beziehungen und ihre Begründung |
| Eigene Schartenkandidaten | Leerer Punktlayer für vermutete Scharten |
| Datenumfang und Startfenster | Äußerer Datenrand und lokaler Einstiegsausschnitt |
| Höhenlinien – 25 m | Orientierung im Relief; aus demselben DGM abgeleitet |
| Relief – Höhenfarbe mit Schummerung | Bereits gerenderte Orientierungskarte, kein Höhenraster für Berechnungen |
| dgm_10m | Originale Höhenwerte im GeoTIFF (Analysegrundlage); zunächst ausgeblendet |
| Schummerung (315° / 45°) | Separates Darstellungsraster, Beleuchtung aus 315° bei 45° Höhe |

A (2564,26 m) und B (2592,12 m) bilden den lokalen Einstieg. C (2659,54 m) liegt nahe dem südlichen Datenrand. D (2716,06 m) ist der höchste Rasterpunkt dieses Ausschnitts. E und F sind weitere ausgewählte lokale Maxima.

Die Kandidaten wurden unter lokalen Maxima einer 31 × 31 Zellen großen Nachbarschaft ausgewählt. Diese Auswahl ist eine Lehrvorbereitung, keine vollständige Gipfelerkennung. Alle Analysen sollen das gesamte relevante Gelände berücksichtigen, nicht nur diese sechs Punkte.

## Arbeitsfolge im Seminar

### 1. Lokale Hypothese

Untersucht A und B. Zeichnet im Layer `Eigene Verbindungen und Hypothesen` einen vermuteten Verbindungsweg ein. Markiert einen Schartenkandidaten und erläutert, warum dieser relevant sein könnte. Noch keine endgültige E-Bewertung vornehmen.

### 2. Umgebung einbeziehen

Zoomt auf den vollständigen DGM-Layer. Welche weiteren höheren Bereiche und Verbindungen kommen infrage? Überprüft eure Hypothese. Untersucht anschließend B als Zielgipfel: Welche Rolle können C und D spielen? Das Hinein- und Herauszoomen verändert nur die Ansicht, nicht das zugrunde liegende Höhenmodell.

### 3. Höheres Gelände sichtbar machen

Im klassischen QGIS-Rasterrechner `Raster → Rasterrechner` für A:

```text
"dgm_10m@1" > 2564.257080078125
```

Den tatsächlichen Bandnamen über die Rasterbandliste einsetzen. Ausgabeausdehnung vom DGM übernehmen, 324 Spalten und 360 Zeilen beibehalten und EPSG:31254 verwenden. Die Ergebniswerte sind 0 und 1. Den Wert 0 transparent, 1 farbig darstellen. Für B die Höhe aus dessen Attributtabelle einsetzen.

Optional: GDAL-Werkzeug **Proximity (Rasterentfernung)** auf diese Maske anwenden. Zielwert `1`, Entfernungseinheiten **georeferenzierte Koordinaten** (Meter). Der Wert an der Gipfelzelle ist die rasterbasierte Entfernung zum nächsten höheren Pixel. Das Verfahren misst zwischen Zellzentren. Erst prüfen, ob ein nicht erfasster Bereich außerhalb der Daten näher sein könnte.

### 4. Verbindung über Höhenstufen prüfen

Im Rasterrechner:

```text
"dgm_10m@1" > 2500
```

2500 ist lediglich ein frei gewählter Startwert. Mehrere Höhenstufen erzeugen und die Stufe jeweils ändern. Beobachtet, wann die Fläche des Zielgipfels mit Gelände verbunden ist, das höher als der Zielgipfel liegt. Eine Verbindung zu irgendeinem niedrigeren Gipfel genügt nicht.

Falls Zusammenhangsflächen polygonisiert werden: eine definierte Raster-Nachbarschaft verwenden und dokumentieren. Die 4er- und 8er-Nachbarschaft können an diagonalen Kontakten abweichen.

### 5. Ergebnisse dokumentieren

Im Gipfellayer stehen zunächst leere Felder für `scharte_m`, `dominanz_m`, `prominenz_m` und `e_wert`. Erst nach begründeter Bestimmung eintragen. `status` hält fest, ob das Ergebnis vorläufig, auf den Ausschnitt beschränkt oder räumlich abgesichert ist.

## Der Datenrand bleibt Teil der Aufgabe

Das kleine Repository-DGM eignet sich zum lokalen Nachvollziehen und zur Untersuchung von Randproblemen. Es garantiert nicht für jeden enthaltenen Gipfel einen vollständigen E-Wert.

Insbesondere für D fehlt im Ausschnitt höheres Gelände. Die Leerstelle ist kein Dominanzwert von null und kein Beleg für maximale Eigenständigkeit. Auch bei anderen Punkten können Verbindungen außerhalb des Ausschnitts relevant werden. Der Rahmen des Datenumfangs ist deshalb sichtbar. Ein endgültiger E-Wert ist nicht vorgegeben.

## Dateien und technische Prüfung

`daten/arbeit.gpkg` enthält die Vektorlayer einschließlich der leeren Arbeitslayer. Die drei GeoTIFFs liegen daneben. `Lesezeichen.xml` kann bei Bedarf in der QGIS-Lesezeichenverwaltung importiert werden; die beiden Ansichten sind zusätzlich über Startansicht und „Auf Layer zoomen“ erreichbar.

`Projektuebersicht.png` ist eine aus den Daten erzeugte Übersichtskarte, kein Screenshot aus QGIS.

Quellen:
- https://github.com/gisma/perfectPeak/tree/37b49f1
- https://github.com/gisma/perfectPeak/blob/37b49f1/man/DEM.Rd
- https://www.tirol.gv.at/data/nutzungsbedingungen/
- https://creativecommons.org/licenses/by/3.0/at/
